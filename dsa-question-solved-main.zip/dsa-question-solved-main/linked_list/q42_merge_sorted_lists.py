# Merge Two Sorted Linked Lists

class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def merge_sorted_lists(l1, l2):
    dummy = ListNode()
    curr = dummy
    
    while l1 and l2:
        if l1.val <= l2.val:
            curr.next = l1
            l1 = l1.next
        else:
            curr.next = l2
            l2 = l2.next
        curr = curr.next
    
    # attach whatever is left
    if l1:
        curr.next = l1
    else:
        curr.next = l2
    
    return dummy.next


def build_list(values):
    dummy = ListNode()
    curr = dummy
    for v in values:
        curr.next = ListNode(v)
        curr = curr.next
    return dummy.next


def print_list(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    print(result)


v1 = list(map(int, input("Enter list1 values: ").split()))
v2 = list(map(int, input("Enter list2 values: ").split()))

l1 = build_list(v1)
l2 = build_list(v2)

merged = merge_sorted_lists(l1, l2)
print_list(merged)
