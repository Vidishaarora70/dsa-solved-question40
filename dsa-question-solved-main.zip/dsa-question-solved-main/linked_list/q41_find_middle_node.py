# Find Middle Node of Linked List (Slow & Fast Pointer)

class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def find_middle(head):
    slow = head
    fast = head
    
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
    
    return slow


def build_list(values):
    dummy = ListNode()
    curr = dummy
    for v in values:
        curr.next = ListNode(v)
        curr = curr.next
    return dummy.next


def print_from_node(node):
    result = []
    while node:
        result.append(node.val)
        node = node.next
    print(result)


values = list(map(int, input("Enter linked list values: ").split()))
head = build_list(values)
mid = find_middle(head)
print_from_node(mid)
