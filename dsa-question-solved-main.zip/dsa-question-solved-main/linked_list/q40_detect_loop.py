# Detect Loop in Linked List (Floyd's Cycle Detection)

class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def has_cycle(head):
    slow = head
    fast = head
    
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        
        if slow == fast:
            return True
    
    return False


# building a test case with a cycle manually
# list: 3 -> 2 -> 0 -> -4 -> back to node with val 2
n1 = ListNode(3)
n2 = ListNode(2)
n3 = ListNode(0)
n4 = ListNode(-4)

n1.next = n2
n2.next = n3
n3.next = n4
n4.next = n2  # cycle here

print("Has cycle:", has_cycle(n1))  # True

# no cycle case
a = ListNode(1)
b = ListNode(2)
a.next = b
print("Has cycle:", has_cycle(a))   # False
