# Reverse a Singly Linked List

class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def reverse_linked_list(head):
    prev = None
    curr = head
    
    while curr:
        next_node = curr.next
        curr.next = prev
        prev = curr
        curr = next_node
    
    return prev


# helper to build linked list from a list
def build_list(values):
    dummy = ListNode()
    curr = dummy
    for v in values:
        curr.next = ListNode(v)
        curr = curr.next
    return dummy.next


# helper to print linked list
def print_list(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    print(result)


values = list(map(int, input("Enter linked list values: ").split()))
head = build_list(values)
reversed_head = reverse_linked_list(head)
print_list(reversed_head)
