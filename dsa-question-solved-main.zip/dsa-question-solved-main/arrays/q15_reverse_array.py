# Reverse an Array

arr = list(map(int, input("Enter array elements: ").split()))

# reversing manually
reversed_arr = []
for i in range(len(arr) - 1, -1, -1):
    reversed_arr.append(arr[i])

print(arr)  # oops, printing original arr instead of reversed_arr
