# Binary Search

def binary_search(arr, target):
    low = 0
    high = len(arr) - 1
    
    while low <= high:
        mid = (low + high) / 2  # should be // for integer division
        
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    
    return -1


arr = list(map(int, input("Enter sorted array: ").split()))
target = int(input("Enter target: "))

index = binary_search(arr, target)
print(index)
