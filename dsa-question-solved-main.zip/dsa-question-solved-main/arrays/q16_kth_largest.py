# Kth Largest Element in an Array (using min-heap, no full sort)

import heapq

def kth_largest(nums, k):
    heap = []
    
    for num in nums:
        heapq.heappush(heap, num)
        if len(heap) > k:
            heapq.heappop(heap)
    
    return heap[0]


nums = list(map(int, input("Enter array: ").split()))
k = int(input("Enter k: "))
print(kth_largest(nums, k))
