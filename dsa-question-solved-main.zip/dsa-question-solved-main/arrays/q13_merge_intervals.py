# Merge Overlapping Intervals

def merge_intervals(intervals):
    intervals.sort(key=lambda x: x[0])
    
    merged = [intervals[0]]
    
    for i in range(1, len(intervals)):
        start = intervals[i][0]
        end = intervals[i][1]
        
        if start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    
    return merged


n = int(input("Enter number of intervals: "))
intervals = []
for i in range(n):
    a, b = map(int, input().split())
    intervals.append([a, b])

print(merge_intervals(intervals))
