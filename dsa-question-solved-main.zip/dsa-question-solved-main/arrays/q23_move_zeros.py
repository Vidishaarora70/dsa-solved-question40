# Move All Zeros to End (in-place)

def move_zeros(nums):
    pos = 0
    
    for i in range(len(nums)):
        if nums[i] != 0:
            nums[pos] = nums[i]
            pos += 1
    
    # fill remaining spots with 0
    while pos < len(nums):
        nums[pos] = 0
        pos += 1
    
    return nums


nums = list(map(int, input("Enter array: ").split()))
print(move_zeros(nums))
