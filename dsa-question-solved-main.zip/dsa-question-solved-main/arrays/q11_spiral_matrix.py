# Traverse a Matrix in Spiral Format

def spiral_order(matrix):
    result = []
    
    while matrix:
        # take the first row
        result += matrix.pop(0)
        
        # take the last element of each remaining row (right column)
        if matrix and matrix[0]:
            for row in matrix:
                result.append(row.pop())
        
        # take the last row in reverse
        if matrix:
            result += matrix.pop()[::-1]
        
        # take the first element of each remaining row going up (left column)
        if matrix and matrix[0]:
            for row in matrix[::-1]:
                result.append(row.pop(0))
    
    return result


r, c = map(int, input().split())
matrix = []
for i in range(r):
    row = list(map(int, input().split()))
    matrix.append(row)

output = spiral_order(matrix)
print(' '.join(map(str, output)))
