# Rotate Array to the Right by k Steps

def rotate(nums, k):
    n = len(nums)
    k = k % n
    nums[:] = nums[-k:] + nums[:-k]
    return nums


nums = list(map(int, input("Enter array: ").split()))
k = int(input("Enter k: "))
print(rotate(nums, k))
