# Check if Two Matrices are Identical

def are_identical(A, B):
    if len(A) != len(B):
        return False
    for i in range(len(A)):
        if A[i] != B[i]:
            return False
    return True


n = int(input("Enter size of matrix (n x n): "))

print("Enter Matrix A:")
A = []
for i in range(n):
    row = list(map(int, input().split()))
    A.append(row)

print("Enter Matrix B:")
B = []
for i in range(n):
    row = list(map(int, input().split()))
    B.append(row)

if are_identical(A, B):
    print("Matrices are identical")
else:
    print("Matrices are not identical")
