# Second Smallest and Second Largest in an Array

def second_smallest_largest(arr):
    unique = sorted(set(arr))
    
    if len(unique) < 2:
        print("Second Smallest : -1")
        print("Second Largest : -1")
        return
    
    print(f"Second Smallest : {unique[1]}")
    print(f"Second Largest : {unique[-2]}")


arr = list(map(int, input("Enter array elements: ").split()))
second_smallest_largest(arr)
