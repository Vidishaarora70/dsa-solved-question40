# Count how many times each integer appears in an array

n = int(input())
arr = list(map(int, input().split()))

counts = {}
for num in arr:
    if num in counts:
        counts[num] += 1
    else:
        counts[num] = 1

for key in sorted(counts):
    print(f"{key} occurs {counts[key]} times")
