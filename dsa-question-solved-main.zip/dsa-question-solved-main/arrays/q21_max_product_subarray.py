# Maximum Product Subarray

def max_product(nums):
    max_p = nums[0]
    min_p = nums[0]
    result = nums[0]
    
    for i in range(1, len(nums)):
        num = nums[i]
        
        # when we multiply by negative, max becomes min and vice versa
        candidates = (num, max_p * num, min_p * num)
        max_p = max(candidates)
        min_p = min(candidates)
        
        result = max(result, max_p)
    
    return result


nums = list(map(int, input("Enter array: ").split()))
print(max_product(nums))
