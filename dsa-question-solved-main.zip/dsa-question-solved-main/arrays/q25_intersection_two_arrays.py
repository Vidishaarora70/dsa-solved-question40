# Intersection of Two Arrays

def intersection(nums1, nums2):
    set1 = set(nums1)
    set2 = set(nums2)
    result = list(set1 & set2)
    return result


nums1 = list(map(int, input("Enter nums1: ").split()))
nums2 = list(map(int, input("Enter nums2: ").split()))
print(intersection(nums1, nums2))
