# Find the Duplicate Number (Floyd's Cycle Detection)

def find_duplicate(arr):
    slow = arr[0]
    fast = arr[0]
    
    # phase 1 - find meeting point
    while True:
        slow = arr[slow]
        fast = arr[arr[fast]]
        if slow == fast:
            break
    
    # phase 2 - find start of cycle
    slow = arr[0]
    while slow != fast:
        slow = arr[slow]
        fast = arr[fast]
    
    return slow


arr = list(map(int, input("Enter array: ").split()))
print(find_duplicate(arr))
