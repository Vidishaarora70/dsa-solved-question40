# Missing Number
# Given array of n distinct numbers in range [0, n], find the missing one

def missing_number(nums):
    n = len(nums)
    # sum of 0 to n should be n*(n+1)//2
    expected = n * (n + 1) // 2
    return expected - sum(nums)


nums = list(map(int, input("Enter array: ").split()))
print(missing_number(nums))
