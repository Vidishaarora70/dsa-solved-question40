# Rotate a 2D Matrix by 90 Degrees Clockwise

def rotate_matrix(matrix):
    n = len(matrix)
    
    # first transpose the matrix
    for i in range(n):
        for j in range(i + 1, n):
            matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]
    
    # then reverse each row
    for i in range(n):
        matrix[i].reverse()
    
    return matrix


# taking input
rows = int(input("Enter number of rows: "))
matrix = []
for i in range(rows):
    row = list(map(int, input().split()))
    matrix.append(row)

rotated = rotate_matrix(matrix)
print("Rotated Matrix:")
for row in rotated:
    print(row)
