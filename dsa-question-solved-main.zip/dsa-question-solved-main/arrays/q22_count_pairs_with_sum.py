# Count Pairs with Given Sum

def count_pairs(arr, target):
    count = 0
    freq = {}
    
    for num in arr:
        complement = target - num
        if complement in freq:
            count += freq[complement]
        
        if num in freq:
            freq[num] += 1
        else:
            freq[num] = 1
    
    return count


arr = list(map(int, input("Enter array: ").split()))
target = int(input("Enter target: "))
print(count_pairs(arr, target))
