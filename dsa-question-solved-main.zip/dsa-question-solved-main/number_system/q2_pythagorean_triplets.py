# Pythagorean Triplets up to a given limit

def pythagorean_triplets(limit):
    for a in range(1, limit):
        for b in range(a, limit):
            c_sq = a*a + b*b
            c = int(c_sq ** 0.5)
            if c * c == c_sq and c <= limit:
                print(a, b, c)


limit = int(input("Enter limit: "))
pythagorean_triplets(limit)
