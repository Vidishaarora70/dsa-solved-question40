# Solve: a³ + a²b + 2a²b + 2ab² + ab² + b³
# Simplifies to: a³ + 3a²b + 3ab² + b³ = (a+b)³

def solve_equation(a, b):
    result = a**3 + (a**2)*b + 2*(a**2)*b + 2*a*(b**2) + a*(b**2) + b**3
    return result


a = int(input("Enter value of a: "))
b = int(input("Enter value of b: "))

ans = solve_equation(a, b)
print(f"Result: {ans}")
