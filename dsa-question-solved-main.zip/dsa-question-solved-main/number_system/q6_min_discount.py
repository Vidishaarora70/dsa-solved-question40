# Find item(s) with minimum discount

n = int(input())

items = []
for i in range(n):
    line = input().split(',')
    name = line[0]
    price = int(line[1])
    discount_pct = int(line[2])
    discount_amount = (price * discount_pct) // 100
    items.append((name, discount_amount))

min_discount = min(items, key=lambda x: x[1])[1]

for name, disc in items:
    if disc == min_discount:
        print(name)
