# Dealership Tyres Calculator

n = int(input())

for i in range(n):
    cars, bikes = map(int, input().split())
    total_tyres = (cars * 4) + (bikes * 2)
    print(total_tyres)
