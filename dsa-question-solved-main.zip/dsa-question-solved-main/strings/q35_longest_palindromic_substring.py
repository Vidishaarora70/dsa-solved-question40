# Longest Palindromic Substring

def longest_palindrome(s):
    result = ""
    
    for i in range(len(s)):
        # odd length palindromes
        l, r = i, i
        while l >= 0 and r < len(s) and s[l] == s[r]:
            if (r - l + 1) > len(result):
                result = s[l:r+1]
            l -= 1
            r += 1
        
        # even length palindromes
        l, r = i, i + 1
        while l >= 0 and r < len(s) and s[l] == s[r]:
            if (r - l + 1) > len(result):
                result = s[l:r+1]
            l -= 1
            r += 1
    
    return result


s = input("Enter string: ")
print(longest_palindrome(s))
