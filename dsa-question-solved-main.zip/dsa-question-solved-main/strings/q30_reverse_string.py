# Reverse a String

s = input("Enter string: ")

# just slicing backwards
reversed_s = s[::-1]
print(reversed_s)
