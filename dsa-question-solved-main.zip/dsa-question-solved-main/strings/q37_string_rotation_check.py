# String Rotation Check

def is_rotation(s, goal):
    if len(s) != len(goal):
        return False
    
    # if goal is a rotation of s, it will appear in s+s
    doubled = s + s
    if goal in doubled:
        return True
    return False


s = input("Enter s: ")
goal = input("Enter goal: ")
print(is_rotation(s, goal))
