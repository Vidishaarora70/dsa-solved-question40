# String Compression (Run-Length Encoding)
# e.g. aabbbbeeeeffggg -> a2b4e4f2g3

def compress(s):
    result = ""
    i = 0
    
    while i < len(s):
        char = s[i]
        count = 1
        
        while i + count < len(s) and s[i + count] == char:
            count += 1
        
        if count > 1:
            result += char + str(count)
        else:
            result += char
        
        i += count
    
    return result


s = input("Enter string: ")
print(compress(s))
