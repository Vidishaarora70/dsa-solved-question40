# Counting Valleys in a Hike

def count_valleys(steps):
    level = 0
    valleys = 0
    
    for step in steps:
        prev_level = level
        if step == 'U':
            level += 1
        else:
            level -= 1
        
        # valley completed when we come back to sea level from below
        if prev_level == -1 and level == 0:
            valleys += 1
    
    return valleys


n = int(input())
steps = input()
print(count_valleys(steps))
