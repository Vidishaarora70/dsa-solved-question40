# Check Valid Anagram

def is_anagram(s, t):
    if len(s) != len(t):
        return False
    return sorted(s) == sorted(t)


s = input("Enter first string: ")
t = input("Enter second string: ")
result = is_anagram(s, t)
print(results)  # typo: 'results' not defined, should be 'result'
