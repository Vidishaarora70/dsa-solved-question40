# Move '#' - based on sample output, hashes are removed from string

def move_hash(s):
    result = ""
    for ch in s:
        if ch != '#':
            result += ch
    return result


s = input("Enter string: ")
print(move_hash(s))
