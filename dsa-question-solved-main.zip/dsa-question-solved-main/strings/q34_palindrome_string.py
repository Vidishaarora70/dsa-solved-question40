# Palindrome String Check

def is_palindrome(s):
    # check if string reads the same forwards and backwards
    rev = s[::-1]
    if s == rev:
        return True
    else:
        return False


s = input("Enter string: ")
print(is_palindrome(s))
