# Longest Substring Without Repeating Characters (Sliding Window)

def length_of_longest_substring(s):
    char_index = {}
    max_len = 0
    start = 0
    
    for i in range(len(s)):
        ch = s[i]
        if ch in char_index and char_index[ch] >= start:
            start = char_index[ch] + 1
        char_index[ch] = i
        max_len = max(max_len, i - start + 1)
    
    return max_len


s = input("Enter string: ")
print(length_of_longest_substring(s))
