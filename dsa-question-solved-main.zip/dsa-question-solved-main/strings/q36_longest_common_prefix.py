# Longest Common Prefix

def longest_common_prefix(strs):
    if not strs:
        return ""
    
    prefix = strs[0]
    
    for i in range(1, len(strs)):
        while not strs[i].startswith(prefix):
            prefix = prefix[:-1]
            if prefix == "":
                return ""
    
    return prefix


n = int(input("Enter number of strings: "))
strs = []
for i in range(n):
    strs.append(input())

print(longest_common_prefix(strs))
